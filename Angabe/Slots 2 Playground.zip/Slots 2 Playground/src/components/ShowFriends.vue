<template>
  <div>
    <h3>
      <slot name="title"> </slot>
    </h3>
    <div v-for="(friend, i) of friends" :key="i">
      <span>{{ friend.name }}</span>
    </div>
  </div>
</template>



<script>
export default {
  props: {
    friends: {
      type: Array,
    },
  },
};
</script>
